package example

import org.specs2.mutable.SpecWithJUnit

class Specs2ExampleTest extends SpecWithJUnit {
  "works" in {
    1 mustEqual 1
  }
}
