package scalarules.test


object Usage {
  def totV: Int = TestPointA.getV + TestPointA.getV
}
