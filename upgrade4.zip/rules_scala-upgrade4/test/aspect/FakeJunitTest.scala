package test.aspect

import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(classOf[JUnit4])
class FakeJunitTest {
  @Test
  def fakeTest(): Unit = {}
}
