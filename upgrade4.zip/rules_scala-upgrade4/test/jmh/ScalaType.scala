package foo

case class ScalaType(n : Int)