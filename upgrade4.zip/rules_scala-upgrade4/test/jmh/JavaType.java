package foo;

public class JavaType {
  public int i = 0;
}
