package scalarules.test.scalafmt
object Format {
  def main(args: Array[String]) {
    val warnings: String = "Be careful with this test. The column number is limited to 40, so it should be in new line."
  }
}
