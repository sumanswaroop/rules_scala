package scalarules.test.scalafmt
import org.scalatest._
class FormatTest extends FlatSpec {
  "FormatTest" should "be formatted" in {
    assert(true)
  }
}
