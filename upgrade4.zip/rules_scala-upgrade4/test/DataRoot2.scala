package scalarules.test


object TestPointB {
  def getV: Int = 66
}
