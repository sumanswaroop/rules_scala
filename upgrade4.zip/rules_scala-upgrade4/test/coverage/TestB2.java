package coverage;

import org.junit.Test;
import org.junit.Assert.*;

public class TestB2 {

    @Test
    public void testB2() {
        B2.b2_b();
    }

}
