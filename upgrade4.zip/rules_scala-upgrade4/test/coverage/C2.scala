package coverage;

object C2 {
  def c2(input: String): String =
    input.reverse

}
