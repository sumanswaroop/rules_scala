package coverage;

object B1 {

  def not_called(): Unit = {
    println("hello world")
  }

}
