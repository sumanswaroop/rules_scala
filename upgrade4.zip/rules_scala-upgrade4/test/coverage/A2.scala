package coverage;

object A2 {
  def a2(): Unit = {
    println("a2: " + B2.b2_a()
    )
  }
}
