package coverage;

class B2 {
    public static String b2_a() {
        return C2.c2("hello from b2_a");
    }

    public static void b2_b() {
        System.out.println("this is b2_b");
    }
}
