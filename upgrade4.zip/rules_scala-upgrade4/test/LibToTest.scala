package scalarules.test

object LibToTest {
  def foo = TestUtil.foo
}
