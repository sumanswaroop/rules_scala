package foo

object Bar {
  def values: List[Int] = List(2, 3, 5, 7)
}
