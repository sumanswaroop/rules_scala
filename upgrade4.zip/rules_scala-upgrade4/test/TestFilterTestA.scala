package scalarules.test

import org.scalatest.FunSpec

class TestFilterTestA extends FunSpec {
  describe("A") {
    it ("tests a") {
      assert(true)
    }
  }
}
