package scalarules.test;

public class JavaUsesScalaStdLib {

  public static <A, B> scala.collection.immutable.Map<A, B> scalaMap(java.util.Map<A, B> javaMap) {
    return null;
  }
}
