package scalarules.test

object A {
  def main(args: Array[String]) {
    println("4 8 15 16 23 42")
  }
}
