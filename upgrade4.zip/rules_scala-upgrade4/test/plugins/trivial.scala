package trivial

object Trivial {
  // feel free to reuse this file for other plugin tests
}
