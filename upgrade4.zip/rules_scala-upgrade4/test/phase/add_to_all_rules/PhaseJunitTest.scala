package scalarules.test.phase.add_to_all_rules

import org.junit.Test

class PhaseJunitTest {
  @Test
  def someTest: Unit = {
    val message = "You can customize junit test phases!"
  }
} 
