package scalarules.test.phase.add_to_all_rules

object PhaseBinary {
  def main(args: Array[String]) {
    val message = "You can customize binary phases!"
  }
}
