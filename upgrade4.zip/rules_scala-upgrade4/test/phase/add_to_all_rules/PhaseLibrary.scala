package scalarules.test.phase.add_to_all_rules

object PhaseLibrary {
  val message = "You can customize library phases!"
}
