package scalarules.test.phase.adjustment

object PhaseLibrary {
  val message = "You can customize library phases!"
}
