package test.v2

object Library {
  def method1(): String = "hello"
  def method2(): String = "world"
}
