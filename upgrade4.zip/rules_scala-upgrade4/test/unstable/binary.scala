package test.v2

object Binary {
  def main(args: Array[String]): Unit = {
    println(s"${Library.method1} ${Library.method2}")
  }
}
