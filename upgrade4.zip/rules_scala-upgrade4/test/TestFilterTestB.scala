package scalarules.test

import org.scalatest.FunSpec

class TestFilterTestB extends FunSpec {
  describe("B") {
    it ("tests b") {
      assert(true)
    }
  }
}
