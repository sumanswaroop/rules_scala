
class B extends A {
	override val Number: Int = 12
}
