package scalarules.test

class Runtime {
  override def toString = "I am Runtime"
}
