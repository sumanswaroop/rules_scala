#!/usr/bin/env bash

echo "Executing: " $@
$@
