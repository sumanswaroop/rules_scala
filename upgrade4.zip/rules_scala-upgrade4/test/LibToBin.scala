package scalarules.test

object LibToBin {
  def foo = ScalaLibBinary.main(Array("foo"))
}
