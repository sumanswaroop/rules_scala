package neverlink

class A