package scalarules.test.large_classpath

object ObjectWithLargeClasspath extends App {
	println("running")
}
