package scala_rules.bazel
import cats.implicits._


object TestObj {}

