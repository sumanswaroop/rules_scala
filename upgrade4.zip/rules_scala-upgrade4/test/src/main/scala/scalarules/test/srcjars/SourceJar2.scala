package scalarules.test.srcjars

object SourceJar2 {
  def msg = SourceJar1.msg
}
