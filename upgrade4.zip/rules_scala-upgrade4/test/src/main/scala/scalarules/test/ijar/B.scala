package scalarules.test.ijar

object B {
	def foo = {
		println("orig")
	}

	def bar = {
		println("orig_sibling")
	}
}
