namespace java scalarules.test.twitter_scrooge.prefix_test.a.b.c.d

include "b/c/d/A.thrift"

struct StructB {
  1: A.StructA field
}
