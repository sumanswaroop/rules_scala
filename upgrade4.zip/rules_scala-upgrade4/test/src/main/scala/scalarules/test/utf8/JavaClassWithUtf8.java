package scalarules.test.utf8;

class JavaClassWithUtf8 {
  public static final String UTF_8_STR = "‡";
}
