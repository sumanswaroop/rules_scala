namespace java scalarules.test.twitter_scrooge.prefix_test.a.b.c.d

struct StructA {
  1: string field
}
