struct Many1 {
  1: i32 one
}
