namespace java scalarules.test.twitter_scrooge.thrift.thrift2

include "thrift3/Thrift3.thrift"

struct Struct2A {
  1: Thrift3.Struct3 msg
}