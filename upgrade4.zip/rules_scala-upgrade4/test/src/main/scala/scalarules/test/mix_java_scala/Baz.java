package scalarules.test;

public class Baz extends Foo {}
