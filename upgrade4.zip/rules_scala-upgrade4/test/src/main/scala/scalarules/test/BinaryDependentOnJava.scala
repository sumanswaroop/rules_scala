package scalarules.test

object BinaryDependentOnJava extends App {
  println(classOf[Alpha])
}
