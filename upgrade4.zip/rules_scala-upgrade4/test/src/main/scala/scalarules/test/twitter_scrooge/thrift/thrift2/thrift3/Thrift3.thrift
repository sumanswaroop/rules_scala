namespace java scalarules.test.twitter_scrooge.thrift.thrift2.thrift3

struct Struct3 {
  1: string msg
}

struct Struct3Extra {
  1: string msg
}