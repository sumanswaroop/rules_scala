package scalarules.test.utf8

class ScalaClassWithUtf8 {
	val Utf8String: String = "‡"
}
