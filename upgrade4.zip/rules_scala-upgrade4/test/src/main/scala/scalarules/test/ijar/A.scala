package scalarules.test.ijar

object A {
	def foo = {
		B.foo
		C.foo
	}
}
