package scalarules.test.twitter_scrooge;

import scalarules.test.twitter_scrooge.thrift.Struct1;
import scalarules.test.twitter_scrooge.thrift.thrift2.Struct2A;
import scalarules.test.twitter_scrooge.thrift.thrift2.Struct2B;
import scalarules.test.twitter_scrooge.thrift.thrift2.thrift3.Struct3;

public class JustScrooge1 {
  public static void main(String[] args) {
  }
}
