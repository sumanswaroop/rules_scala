package scalarules.test.junit

import org.junit.Test
//Used to verify a folder doesn't match in test discovery.
//See JunitMatchesOnlyFilesEvenIfFolderMatchesPattern target
class scala {

  @Test
  def atLeastOneTestIsNeeded: Unit = {
  }

}
