package fish

object JavaDependent {
  val poem = JavaSource.line + "\nred fish, blue fish\nblack fish, blue fish\nold fish, new fish"
}