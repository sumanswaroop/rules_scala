namespace java scalarules.test.twitter_scrooge.thrift.thrift2.thrift3

include "../Thrift2_A.thrift"

struct Struct4 {
  1: Thrift2_A.Struct2A nested
}
