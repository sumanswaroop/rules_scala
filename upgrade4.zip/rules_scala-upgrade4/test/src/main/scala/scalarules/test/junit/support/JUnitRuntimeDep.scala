package scalarules.test.junit.support
class JUnitRuntimeDep
