package scalarules.test.twitter_scrooge

import scalarules.test.twitter_scrooge.thrift.thrift2.thrift3.Struct3

object JustScrooge3 {
  val classes = Seq(classOf[Struct3])
}
