package scalarules.test.junit;

import org.junit.Test;

public class JunitJavaTest {
  @Test
  public void someTest() {}
}
