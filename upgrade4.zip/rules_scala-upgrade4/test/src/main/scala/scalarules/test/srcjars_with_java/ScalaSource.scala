package fish

object ScalaSource {
  final val line = "red fish, blue fish";
}