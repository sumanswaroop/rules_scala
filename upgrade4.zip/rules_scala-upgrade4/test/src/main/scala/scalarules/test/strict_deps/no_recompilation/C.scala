package scalarules.test.strict_deps.no_recompilation;

object C {
	def foo = {
		println("orig")
	}
}
