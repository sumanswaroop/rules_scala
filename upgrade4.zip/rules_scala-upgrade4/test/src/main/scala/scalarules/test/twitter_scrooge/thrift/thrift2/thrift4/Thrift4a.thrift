include "./Thrift4.thrift"

struct Struct4a {
  1: Thrift4.Struct4 nest;
}
