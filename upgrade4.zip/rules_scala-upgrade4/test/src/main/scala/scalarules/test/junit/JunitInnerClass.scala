package scalarules.test.junit

import org.junit.Test

class TestClass {
  @Test
  def someTest: Unit =
  	println("passing")

  class SomeHelper	
} 
