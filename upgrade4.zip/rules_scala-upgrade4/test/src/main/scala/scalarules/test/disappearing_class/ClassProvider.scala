package scalarules.test

object BackgroundNoise{}
