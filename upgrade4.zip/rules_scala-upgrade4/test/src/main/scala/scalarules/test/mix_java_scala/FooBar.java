package scalarules.test;

public class FooBar extends Foo {}
