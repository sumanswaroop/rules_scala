package scalarules.test.junit.separate_target;

import org.junit.Test;

public class JunitJavaSeparateTargetTest {

  @Test
  public void someTest() {

  }
}
