struct Many2 {
  1: i16 two
}
