package scalarules.test.scala_import

import cats.implicits._

object TestObj {}

