package scalarules.test.srcjars

object SourceJar1 {
  def msg = "I want to go back to the island"
}
