package scalarules.test;

public class Alpha {
  public static void main(String[] args) {
    return; // we just want this to be compiled and run
  }
}
