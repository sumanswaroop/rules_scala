package scalarules.test.junit

import org.junit.Test

class HelloWorldJunitTest {

  @Test
  def helloWorld: Unit = {
    println("hello world")
  }

}
