package scalarules.test.junit.support
object JUnitCompileTimeDep {
	val hello = "hello"
}
