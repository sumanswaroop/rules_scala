package scalarules.test.junit.separate_target

class SomeScalaClass {

}
