package scalarules.test.junit.separate_target

import org.junit.Test

class JunitSeparateTargetTest {

  @Test
  def someTest(): Unit = {
  }

}

