package scalarules.test
class Foo
class Bar extends Baz
