package test.longnames.looooooongnaaaaaaame.anooooootherlooooooooongname.anooooootherlooooooooongname2.anooooootherlooooooooongname3

import org.scalatest._

class SomeLoooooooongTestNaaaaaaaaaaaaaaaaaaaaaaaame extends FlatSpec with Matchers {
  "This test" should "pass" in {
    assert(true)
  }
}
