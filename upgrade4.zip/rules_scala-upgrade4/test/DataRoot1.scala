package scalarules.test


object TestPointA {
  def getV: Int = 33
}
