package scalarules.test

object D {
  def main(args: Array[String]) {
    A.main(args)
  }
}
