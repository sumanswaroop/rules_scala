public class PlaceHolderClassToCreateEmptyJarForScalaImport { }
