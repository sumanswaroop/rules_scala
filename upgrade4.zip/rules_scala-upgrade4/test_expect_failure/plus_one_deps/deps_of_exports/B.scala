package scalarules.test_expect_failure.plus_one_deps.internal_deps

class B extends C {
  def hi: String = "hi"
}