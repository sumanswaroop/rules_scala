package scalarules.test_expect_failure.plus_one_deps.internal_deps

class C extends D