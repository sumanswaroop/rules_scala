class WillNotCompileJavaSinceXmxTooLow {}
