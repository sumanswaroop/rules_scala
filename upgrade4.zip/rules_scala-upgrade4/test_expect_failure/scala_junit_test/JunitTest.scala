
import org.junit.Test

class JunitTest {

  @Test
  def running: Unit = {
  }

}
