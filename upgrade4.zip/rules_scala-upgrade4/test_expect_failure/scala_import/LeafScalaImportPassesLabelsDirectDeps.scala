package test_expect_failure.scala_import

class LeafScalaImportPassesLabelsDirectDeps {
  println(classOf[RootScalaImportPassesLabelsDirectDeps])
}