package example;

public class A {
  public static void foo() {
    System.out.println("yeah?");
  }
}
