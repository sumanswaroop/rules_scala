package example

object D {
  def main(args: Array[String]) {
    A.foo
  }
}
