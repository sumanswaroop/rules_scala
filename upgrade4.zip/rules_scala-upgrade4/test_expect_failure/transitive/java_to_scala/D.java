package example;

public class D {
  public static void main(String[] args) {
    A.foo();
  }
}
