package example

object A {
  def foo {
    println("hi")
  }
}
