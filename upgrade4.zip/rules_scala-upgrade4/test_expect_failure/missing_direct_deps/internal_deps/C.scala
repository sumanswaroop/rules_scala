package test_expect_failure.missing_direct_deps.internal_deps;

object C {
	def foo = {
		println("in C")
	}
}