package test_expect_failure.missing_direct_deps.internal_deps;

public class JavaLibraryHasCustomJavaProviderDependency {
  public void foo() {
    C.foo();
  }
}
