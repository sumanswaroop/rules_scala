package scalarules.test

object ClassProvider {
  def dissappearingClassMethod: String = "testContents"
}


object BackgroundNoise{}
