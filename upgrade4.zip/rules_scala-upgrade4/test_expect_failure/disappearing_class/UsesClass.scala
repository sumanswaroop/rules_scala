package scalarules.test

object UsesClass {
  val x = ClassProvider.dissappearingClassMethod
}
