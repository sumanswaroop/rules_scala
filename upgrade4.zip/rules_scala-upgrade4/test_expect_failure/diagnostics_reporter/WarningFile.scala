import java.util.ArrayList

object WarningFile {
  def main(args: Array[String]): Unit = {
    println("this is a print")
  }
}