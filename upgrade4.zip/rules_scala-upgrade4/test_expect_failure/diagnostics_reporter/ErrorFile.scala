object ErrorFile {
  val value = "someVal"

  def main(args: Array[String]): Unit = {
    println(value
  }
}
