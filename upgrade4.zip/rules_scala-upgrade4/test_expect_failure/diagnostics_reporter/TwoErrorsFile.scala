object SimpleFile {
  val value = "someVal"

  def main(args: Array[String]): Unit = {
    printn(value)
    prinf(value)
  }
}
