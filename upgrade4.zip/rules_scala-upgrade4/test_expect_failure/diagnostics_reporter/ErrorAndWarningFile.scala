import java.util.ArrayList

object ErrorAndWarningFile {
  def main(args: Array[String]): Unit = {
    printn("this is not a print")
  }
}