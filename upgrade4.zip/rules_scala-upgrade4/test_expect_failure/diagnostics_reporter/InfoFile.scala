object InfoFile {
  def main(args: Array[String]): Unit = {
    println("this is not a print")
  }
}