This file lists license and version information of all code we did not author

# dependency_analyzer 
dependency_analyzer scala compiler plugin is based on [classpath-shrinker](https://github.com/scalacenter/classpath-shrinker) plugin.
License: 3-clause revised BSD