package test_expect_failure.scala_test_jvm_flags

import org.scalatest.FunSuite

class EmptyTest extends FunSuite {
    test("empty test") {
        assert(true)
    }
}